package com.Pharmacy.web.handlers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.Pharmacy.DAO.AdminDAO;
import com.Pharmacy.DAO.CustomerDAO;
import com.Pharmacy.mvc.HttpRequestHandler;

public class CustomerLogin implements HttpRequestHandler {
	public static Logger log = Logger.getLogger(CustomerLogin.class);
	
	public void handle(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		int uid = Integer.parseInt(request.getParameter("UserID"));
		String password = request.getParameter("password");
		int users = 0;
		CustomerDAO cdao = new CustomerDAO();
		users = CustomerDAO.customerLogin(uid,password);
		log.info(users);


		if (users!=0) {
			HttpSession session= request.getSession();  // new session object will be create with respect to
            session.setAttribute("UserID",uid);
			out.print("Welcome Customer ID - "+uid);
			RequestDispatcher dispatcher = request.getRequestDispatcher("CustomerOperations.jsp");
			/*HttpSession session= request.getSession();
			request.setAttribute("UserID", uid);
			out.print("Welcome, "+uid);*/
			dispatcher.include(request, response);

		}
		else {
			out.println("userID or password is incorrect");
			out.println("Go back and enter valid UserID or Password");
			RequestDispatcher dispatcher = request.getRequestDispatcher("error.jsp");
			dispatcher.include(request, response);

		}

	}
}

