package com.Pharmacy.web.handlers;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
 
public class Validator {
 
    private Pattern pattern;
    private Matcher matcher;
    private Pattern patternEmail;
    private Pattern patternPhone;
 
    private static final String PASSWORD_PATTERN =  "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&-+=()])(?=\\S+$).{8,20}$";
    private static final String PHONE_PATTERN = "(0/91)?[7-9][0-9]{9}";
    private static final String EMAIL_PATTERN  = "^[a-zA-Z0-9_+&*-]+(?:\\."+ 
            "[a-zA-Z0-9_+&*-]+)*@" + 
            "(?:[a-zA-Z0-9-]+\\.)+[a-z" + 
            "A-Z]{2,7}$";
    
    public Validator() {
        pattern = Pattern.compile(PASSWORD_PATTERN);
        patternEmail = Pattern.compile(EMAIL_PATTERN);
        patternPhone = Pattern.compile(PHONE_PATTERN);
    }
 
    public boolean validatePassword(final String password) {
 
        matcher = pattern.matcher(password);
        return matcher.matches();
 
    }
    
    public boolean validateEmail(final String email) {
         
        matcher = patternEmail.matcher(email);
        return matcher.matches();
 
    }
    
    public boolean validatePhone(String phone) {
         matcher = patternPhone.matcher(phone);
         return matcher.matches();
    }
    
}
