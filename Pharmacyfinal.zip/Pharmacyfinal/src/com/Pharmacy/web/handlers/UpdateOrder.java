package com.Pharmacy.web.handlers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.Pharmacy.DAO.OrdersDAO;
import com.Pharmacy.mvc.HttpRequestHandler;

public class UpdateOrder implements HttpRequestHandler{
	public static Logger log = Logger.getLogger(UpdateOrder.class);

	@Override
	public void handle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		OrdersDAO odao = new OrdersDAO();
		int result=0;
		int id=Integer.parseInt(request.getParameter("CustomerID"));
		String name=request.getParameter("CustomerName");
		String phone=request.getParameter("Contact");
		int quantity=Integer.parseInt(request.getParameter("Quantity"));
		String proname=request.getParameter("ProductName");
		String date=request.getParameter("Date");
		String address=request.getParameter("Address");
		
		result=OrdersDAO.updateOrders(id,name,phone,quantity,proname,date,address);
		log.info(result);
		
		if(result!=0)
		{
			out.println("Order Updated successfully");
			RequestDispatcher dispatcher = request.getRequestDispatcher("CustomerOperations.jsp");
			dispatcher.include(request, response);
			//out.println("Order Updated successfully");
		}
		else
		{
			out.println("Failed to Update");
			out.println("Enter Valid Customer ID");
			RequestDispatcher dispatcher = request.getRequestDispatcher("error.jsp");
			dispatcher.include(request, response);
		}
		
		
	}
}


