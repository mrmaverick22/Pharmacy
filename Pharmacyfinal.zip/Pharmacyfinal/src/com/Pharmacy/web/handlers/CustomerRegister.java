package com.Pharmacy.web.handlers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.Pharmacy.DAO.AdminDAO;
import com.Pharmacy.DAO.CustomerDAO;
import com.Pharmacy.Domain.Admin;
import com.Pharmacy.Domain.Customer;
import com.Pharmacy.mvc.HttpRequestHandler;

public class CustomerRegister implements HttpRequestHandler{
	public static Logger log = Logger.getLogger(CustomerRegister.class);

	@Override
	public void handle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		CustomerDAO cdao = new CustomerDAO();
		int result=0;
		Customer c=new Customer();
		
		 Validator valide = new Validator();
		    boolean mailid=valide.validateEmail(request.getParameter("EmailID"));
		    boolean pass=valide.validatePassword(request.getParameter("Password"));
		    boolean phone=valide.validatePhone(request.getParameter("Contact"));
		    
		c.setUserID(Integer.parseInt(request.getParameter("UserID")));
		c.setPassword(request.getParameter("Password"));
		c.setEmailID(request.getParameter("EmailID"));
		c.setAge(Integer.parseInt(request.getParameter("Age")));
		c.setContact(request.getParameter("Contact"));
		c.setState(request.getParameter("State"));
		c.setPincode(request.getParameter("Pincode"));
		
		result=cdao.insertCustomer(c);
		log.info(result);
		
		 
		
		if(mailid==false)
		{
			out.println("Enter Valid EmailID Format: name@mail.com");
			RequestDispatcher dispatcher = request.getRequestDispatcher("CustomerRegister.jsp");
			dispatcher.include(request, response);
		}
		else if(pass==false)
		{
			out.println("Enter Valid Password Format:Must contain at least one  number and one uppercase and lowercase letter, and at least 8 or more characters");
			RequestDispatcher dispatcher = request.getRequestDispatcher("CustomerRegister.jsp");
			dispatcher.include(request, response);
		}
		else if(phone==false)
		{
			out.println("Enter Valid Contact Number Format:Must start with 7-9 number and must have 10 digit number");
			RequestDispatcher dispatcher = request.getRequestDispatcher("CustomerRegister.jsp");
			dispatcher.include(request, response);
		}
		 
		
		else if(result!=0 && mailid==true && pass==true && phone==true)
		{
			out.println("Admin Registered successfully");
			RequestDispatcher dispatcher = request.getRequestDispatcher("Admin.jsp");
			dispatcher.include(request, response);
		}
		else
		{
			out.println("Failed to Register");
			RequestDispatcher dispatcher = request.getRequestDispatcher("error.jsp");
			dispatcher.include(request, response);
		}

	}
}
