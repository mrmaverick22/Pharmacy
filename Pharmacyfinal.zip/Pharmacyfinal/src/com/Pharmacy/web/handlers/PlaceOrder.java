package com.Pharmacy.web.handlers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.Pharmacy.DAO.AdminDAO;
import com.Pharmacy.DAO.OrdersDAO;
import com.Pharmacy.Domain.Admin;
import com.Pharmacy.Domain.Orders;
import com.Pharmacy.mvc.HttpRequestHandler;

public class PlaceOrder implements HttpRequestHandler{
	public static Logger log = Logger.getLogger(PlaceOrder.class);

	@Override
	public void handle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		OrdersDAO odao = new OrdersDAO();
		int result=0;
		int id=Integer.parseInt(request.getParameter("CustomerID"));
		String name=request.getParameter("CustomerName");
		String phone=request.getParameter("Contact");
		int quantity=Integer.parseInt(request.getParameter("Quantity"));
		String proname=request.getParameter("ProductName");
		String date=request.getParameter("Date");
		String address=request.getParameter("Address");
		Orders o=new Orders(id,quantity,name,phone,proname,date,address);
		/*o.setCustomerID(Integer.parseInt(request.getParameter("CustomerID")));
		o.setCustomerName(request.getParameter("CustomerName"));
		o.setPhoneNo(request.getParameter("Contact"));
		o.setQuantity(Integer.parseInt(request.getParameter("Quantity")));
		o.setProductName(request.getParameter("ProductName"));
		o.setReqdate(request.getParameter("Date"));
		o.setAddress(request.getParameter("Address"));*/
		result=odao.insertOrders(o);
		log.info(result);
		
		 
		
		if(result!=0)
		{
			out.println("Placed Order successfully");
			RequestDispatcher dispatcher = request.getRequestDispatcher("AdminOperations.jsp");
			dispatcher.include(request, response);
		}
		else
		{
			out.println("Failed to Place Order");
			RequestDispatcher dispatcher = request.getRequestDispatcher("error.jsp");
			dispatcher.include(request, response);
		}

	}
}
