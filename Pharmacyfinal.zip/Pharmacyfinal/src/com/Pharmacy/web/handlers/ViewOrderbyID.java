package com.Pharmacy.web.handlers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.Pharmacy.DAO.OrdersDAO;
import com.Pharmacy.mvc.HttpRequestHandler;

public class ViewOrderbyID implements HttpRequestHandler{
	public static Logger log = Logger.getLogger(ViewOrderbyID.class);

	@Override
	public void handle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		OrdersDAO odao = new OrdersDAO();
		List orderlist=null;
		int result=0;
		int oid=Integer.parseInt(request.getParameter("UserID"));
		orderlist=OrdersDAO.getOrder(oid);
		log.info(orderlist);
		
		/*if(!(orderlist.isEmpty()))
		{
				out.println("\n\n VALID ORDER DETAILS \n\n");
				out.println("\n\n**** DETAILS OF ORDER *** \n\n");
				out.println("------------------------------------");
				
				for(Iterator it=orderlist.iterator();it.hasNext();)
					
					out.println(it.next());
		
		}
		else
		{
			System.out.println("Invalid order details");
		}*/
		request.setAttribute("orderList",orderlist);
		request.getRequestDispatcher("ViewbyID.jsp").include(request, response);
		
	}
}

