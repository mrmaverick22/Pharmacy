package com.Pharmacy.web.handlers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.regex.Pattern;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.Pharmacy.DAO.AdminDAO;
import com.Pharmacy.Domain.Admin;
import com.Pharmacy.mvc.HttpRequestHandler;

public class AdminRegister implements HttpRequestHandler{
	public static Logger log = Logger.getLogger(AdminRegister.class);
	
	

	@Override
	public void handle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		AdminDAO adao = new AdminDAO();
		int result=0;
		Admin a=new Admin();

	    Validator valide = new Validator();
	    boolean mailid=valide.validateEmail(request.getParameter("EmailID"));
	    boolean pass=valide.validatePassword(request.getParameter("Password"));
	    boolean phone=valide.validatePhone(request.getParameter("Contact"));

		a.setUserID(Integer.parseInt(request.getParameter("UserID")));
		a.setPassword(request.getParameter("Password"));
		a.setEmailID(request.getParameter("EmailID"));
		a.setAge(Integer.parseInt(request.getParameter("Age")));
		a.setContact(request.getParameter("Contact"));
		a.setState(request.getParameter("State"));
		a.setPincode(request.getParameter("Pincode"));
		
		result=adao.insertAdmin(a);
		log.info(result);
		
		if(mailid==false)
		{
			out.println("Enter Valid EmailID Format: name@mail.com");
			RequestDispatcher dispatcher = request.getRequestDispatcher("AdminRegister.jsp");
			dispatcher.include(request, response);
		}
		else if(pass==false)
		{
			out.println("Enter Valid Password Format:Must contain at least one  number and one uppercase and lowercase letter, and at least 8 or more characters");
			RequestDispatcher dispatcher = request.getRequestDispatcher("AdminRegister.jsp");
			dispatcher.include(request, response);
		}
		else if(phone==false)
		{
			out.println("Enter Valid Contact Number Format:Must start with 7-9 number and must have 10 digit number");
			RequestDispatcher dispatcher = request.getRequestDispatcher("AdminRegister.jsp");
			dispatcher.include(request, response);
		}
		 
		
		else if(result!=0 && mailid==true && pass==true && phone==true)
		{
			out.println("Admin Registered successfully");
			RequestDispatcher dispatcher = request.getRequestDispatcher("Admin.jsp");
			dispatcher.include(request, response);
		}
		else
		{
			out.println("Failed to Register");
			out.println("Enter Valid Details");
			RequestDispatcher dispatcher = request.getRequestDispatcher("error.jsp");
			dispatcher.include(request, response);
		}

	}
}