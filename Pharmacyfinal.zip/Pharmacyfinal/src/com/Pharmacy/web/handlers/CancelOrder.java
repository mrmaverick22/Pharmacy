package com.Pharmacy.web.handlers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.Pharmacy.DAO.AdminDAO;
import com.Pharmacy.DAO.OrdersDAO;
import com.Pharmacy.mvc.HttpRequestHandler;

public class CancelOrder implements HttpRequestHandler{
	public static Logger log = Logger.getLogger(CancelOrder.class);

	@Override
	public void handle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		OrdersDAO odao = new OrdersDAO();
		int result=0;
		int id=Integer.parseInt(request.getParameter("CustomerID"));
		
		result=OrdersDAO.deleteOrders(id);
		log.info(result);
		
		if(result!=0)
		{
			out.println("Order Cancelled successfully");
			RequestDispatcher dispatcher = request.getRequestDispatcher("CustomerOperations.jsp");
			dispatcher.include(request, response);
			//out.println("Order deleted successfully");
			//request.setAttribute("success","Order succesfully deleted");
		}
		else
		{
			out.println("Failed to Cancel");
			out.println("Enter Valid Customer ID");
			RequestDispatcher dispatcher = request.getRequestDispatcher("error.jsp");
			dispatcher.include(request, response);
		}
	}
}
