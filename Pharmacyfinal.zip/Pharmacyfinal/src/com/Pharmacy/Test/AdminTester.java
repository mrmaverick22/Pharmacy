package com.Pharmacy.Test;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import com.Pharmacy.DAO.AdminDAO;

@RunWith(Parameterized.class)
public class AdminTester {

	AdminDAO admin;
	int UserID;
	String Password;
	 @Before
	public void initialize() {
		 admin = new AdminDAO();
	}
	 
	 
	public AdminTester(int UserID, String Password) {
		this.UserID = UserID;
		this.Password = Password;
	} 


	@Parameterized.Parameters
	 public static Collection usernamePass() {
		 return Arrays.asList(new Object[][] {
			 { 1, "pass" }
		
		 });
	 }
	 
	 
	@Test
	public void testLogin() {
		String name = null;
		int result=0;
		String name1="ambar";
		
			result=admin.adminLogin(UserID,Password);
			System.out.println(result);
			assertEquals(1,result);
		
		
	}
	}


