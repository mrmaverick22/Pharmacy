package com.Pharmacy.Test;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

public class Runner{

	public static void main(String[] args) {
		
		Result resAdmin = JUnitCore.runClasses(AdminTester.class);
		Result resCustomer = JUnitCore.runClasses(CustomerTester.class);
		Result resInsertAdmin = JUnitCore.runClasses(InsertAdminTester.class);
		Result resDeleteOrder = JUnitCore.runClasses(DeleteOrderTester.class);
		
		
		
		for(Failure failure:resAdmin.getFailures()) {
			System.out.println(failure.toString());
		}
		
		for(Failure failure:resCustomer.getFailures()) {
			System.out.println(failure.toString());
		}
		
		for(Failure failure:resInsertAdmin.getFailures()) {
			System.out.println(failure.toString());
		}
		
		for(Failure failure:resDeleteOrder.getFailures()) {
			System.out.println(failure.toString());
		}
		
		System.out.println("Admin Test "+(resAdmin.wasSuccessful()?"Successful":"Failed"));
		System.out.println("Customer Test "+(resCustomer.wasSuccessful()?"Successful":"Failed"));
		System.out.println("Insert Admin Test "+(resInsertAdmin.wasSuccessful()?"Successful":"Failed"));
		System.out.println("Delete Order Test "+(resDeleteOrder.wasSuccessful()?"Successful":"Failed"));
		
	}

}
