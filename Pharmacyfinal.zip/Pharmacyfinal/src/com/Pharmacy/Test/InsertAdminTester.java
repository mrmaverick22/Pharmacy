package com.Pharmacy.Test;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import com.Pharmacy.DAO.AdminDAO;
import com.Pharmacy.Domain.*;

@RunWith(Parameterized.class)
public class InsertAdminTester {
	
	AdminDAO admin;
	int Admin;
	Admin a=new Admin();

	 @Before
	public void initialize() {
		 admin = new AdminDAO();
	}
	 
	 
	public InsertAdminTester(int Admin) {
		this.Admin = Admin;
		
	} 


	@Parameterized.Parameters
	 public static Collection usernamePass() {
		 return Arrays.asList(new Object[][] {
			 { 1 }
		
		 });
	 }
	 
	 
	@Test
	public void testInsert() {
		
		int result=1;
		
			result=admin.insertAdmin(a);
			assertEquals(0,result);
			//System.out.println(result);
		
		
	}
}
