package com.Pharmacy.Test;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
import org.junit.Test;

/**
 * Servlet implementation class RunnerServlet
 */
@WebServlet("/runTest")
public class RunnerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RunnerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out =  response.getWriter();
		response.getWriter().append("Served at: ").append(request.getContextPath());
		Result resInsertAdmin = JUnitCore.runClasses(InsertAdminTester.class);
		Result resCustomer = JUnitCore.runClasses(CustomerTester.class);
		Result resAdmin = JUnitCore.runClasses(AdminTester.class);
		Result resDeleteOrder = JUnitCore.runClasses(DeleteOrderTester.class);
		
		for(Failure failure:resInsertAdmin.getFailures()) {
			out.println(failure.toString());
		}
		
		for(Failure failure:resCustomer.getFailures()) {
			out.println(failure.toString());
		}
		
		for(Failure failure:resAdmin.getFailures()) {
			out.println(failure.toString());
		}
		
		for(Failure failure:resDeleteOrder.getFailures()) {
			out.println(failure.toString());
		}
		
		out.println("Insert Admin Test "+(resInsertAdmin.wasSuccessful()?"Successful":"Failed/n"));
		out.println("Customer Test "+(resCustomer.wasSuccessful()?"Successful":"Failed/n"));
		out.println("Admin  Test "+(resAdmin.wasSuccessful()?"Successful":"Failed/n"));
		out.println("Delete Order Test "+(resDeleteOrder.wasSuccessful()?"Successful":"Failed/n"));
		//System.out.println("Admin  Test "+(resAdmin.wasSuccessful()));
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

