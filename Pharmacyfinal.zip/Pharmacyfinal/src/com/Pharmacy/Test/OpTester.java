package com.Pharmacy.Test;

import static org.junit.Assert.*;

import org.junit.Test;

public class OpTester {
	
	TestingOperations to=new TestingOperations();
	
	@Test
	public void checkWrongDate() throws Exception
	{
		String date="55/08/2020";
		assertEquals(0,to.validateDate(date));
	}
	
	@Test
	public void checkRightDate() throws Exception
	{
		String date="05/08/2020";
		assertEquals(1,to.validateDate(date));
	}

}
