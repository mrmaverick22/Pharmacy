package com.Pharmacy.Test;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import com.Pharmacy.DAO.CustomerDAO;



@RunWith(Parameterized.class)
public class CustomerTester {

	CustomerDAO customer;
	int UserID;
	String Password;
	 @Before
	public void initialize() {
		 customer = new CustomerDAO();
	}
	 
	 
	public CustomerTester(int UserID, String Password) {
		this.UserID = UserID;
		this.Password = Password;
	} 


	@Parameterized.Parameters
	 public static Collection usernamePass() {
		 return Arrays.asList(new Object[][] {
			 { 1, "pass" }
		
		 });
	 }
	 
	 
	@Test
	public void testLogin() {
		int result=0;
		
			result=customer.customerLogin(UserID,Password);
			System.out.println(result);
			assertEquals(1,result);
			//System.out.println(result);
		
		
	}
}
