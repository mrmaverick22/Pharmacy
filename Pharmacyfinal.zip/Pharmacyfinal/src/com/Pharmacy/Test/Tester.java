package com.Pharmacy.Test;

import static org.junit.Assert.*;

import org.junit.Test;

class Tester {
	
	TableChecker tc=new TableChecker();

	@Test
	public void TableExists() throws Exception
	{
		boolean b=tc.check("admin");
		assertEquals(b,true);
	}

}
