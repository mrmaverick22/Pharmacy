package com.Pharmacy.Test;



public class TestingOperations {
	public int validateDate(String s)
	{
		String d,m,y;
		try
		{
			d=s.substring(0,2);
			m=s.substring(3,5);
			y=s.substring(6);
			
				int dd=Integer.parseInt(d);
				int mm=Integer.parseInt(m);
				int yy=Integer.parseInt(y);
				if(dd>0 && dd<31 && mm>0 && mm<=12 && yy==2020)
				{
					return 1;
				}
		}catch(Exception e)
		{
			return 0;
		}
		return 0;
	}
	

}
