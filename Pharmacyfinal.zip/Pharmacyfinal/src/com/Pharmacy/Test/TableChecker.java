package com.Pharmacy.Test;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;

import com.Pharmacy.dbcon.ConnectionHolder;

public class TableChecker {
	public static boolean check(String tableName) throws Exception
	{
		ConnectionHolder ch=(ConnectionHolder) ConnectionHolder.getInstance();
		Connection con=ConnectionHolder.getConnection();
		DatabaseMetaData dbm=con.getMetaData();
		ResultSet tables=dbm.getTables(null, null, tableName, null);
		
		if(tables.next())
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	
	}


