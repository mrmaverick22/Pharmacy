package com.Pharmacy.dbfw;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.Pharmacy.dbfw.DBFWException;
import com.Pharmacy.dbfw.OutParamMapper;
import com.Pharmacy.dbfw.OutTypeMapper;
import com.Pharmacy.dbfw.ParamMapper;
import com.Pharmacy.dbfw.ResultMapper;

public class DBHelper {
	private DBHelper() {

	}

	public static List executeSelect(Connection con, final String sqlSt, ResultMapper outMap) throws DBFWException
	{
		List resultList=new ArrayList();
		Statement stmt=null;
		ResultSet rs=null;		
		
		try {
			 stmt=con.createStatement();
			 rs=stmt.executeQuery(sqlSt);
			 
			 while(rs.next())
			 {
				 Object obj=outMap.mapRows(rs);
				 resultList.add(obj);
			 }
			 
		} catch (SQLException e) 
		{
			// TODO Auto-generated catch block
				throw new DBFWException("Execution of select failed",e);
	    }finally
		 {
			try {
				if(rs!=null)
				rs.close();
				if(stmt!=null)
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				System.out.println(e);
			}		
	}
		return resultList;
		
	}//executeSelect	
	//Parameterized Select	
	
	public static List executeSelect (Connection con,final String sqlSt,ResultMapper outMap,ParamMapper inMap)
	{
		List resultList=new ArrayList();
		PreparedStatement preStmt=null;
		ResultSet rs=null;
		
		try
		{
			preStmt=con.prepareStatement(sqlSt);
			
			inMap.mapParams(preStmt);
			
			rs=preStmt.executeQuery();
			
			while(rs.next())
			{
				Object ob=outMap.mapRows(rs);
				resultList.add(ob);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return resultList;
		
	}//parameterised exceuteselect
	
	//for insert,delete and update
	
	public static int executeUpdate (Connection con,final String sqlSt, ParamMapper inMap) throws DBFWException
	{
		PreparedStatement preStmt=null;
		
		int result=0;
		
		try 
		{
			preStmt=con.prepareStatement(sqlSt);  // public static final String INSERTCOUNTRY= "insert into country_081 values(?,?)";
			
			inMap.mapParams(preStmt);
			
			result=preStmt.executeUpdate();
			
		} 
		catch (SQLException e) 
		{
			throw new DBFWException("unable to insert"+e);
		}
		
		return result;
		
	}

	public static Object executeProc(Connection conn, String sqlStmt,
			ParamMapper inParam, OutTypeMapper outType, OutParamMapper outParam)
			throws SQLException {
		Object res = null;
		if ((outType == null && outParam != null)
				|| (outType != null && outParam == null)) {
			return null;
		}
		CallableStatement callStmt = conn.prepareCall(sqlStmt);
		inParam.mapParams(callStmt);

		if (outType != null) {
			outType.mapOutType(callStmt);
		}
		callStmt.execute();
		if (outParam != null) {
			res = outParam.mapOutParam(callStmt);
		}

		return res;

	}
	public static List unpackResultset(ResultSet rs, ResultMapper outMap)
			throws DBFWException {
		List resultList = new ArrayList();
		try {
			while (rs.next()) {
				Object obj = outMap.mapRows(rs);
				resultList.add(obj);
			}
		} catch (SQLException e) {
			throw new DBFWException("Unpacking Resultset failed", e);
		}
		return resultList;
	}

}
