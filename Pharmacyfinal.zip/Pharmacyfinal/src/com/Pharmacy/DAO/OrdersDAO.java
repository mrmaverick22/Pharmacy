package com.Pharmacy.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.Pharmacy.DAO.OrdersDAOException;
import com.Pharmacy.DAO.SQLMapper;
import com.Pharmacy.dbcon.ConnectionHolder;
import com.Pharmacy.dbcon.DBConnectionException;
import com.Pharmacy.dbfw.DBFWException;
import com.Pharmacy.dbfw.DBHelper;
import com.Pharmacy.dbfw.ParamMapper;
import com.Pharmacy.Domain.Admin;
import com.Pharmacy.Domain.Orders;
import com.Pharmacy.DAO.AdminDAO;

public class OrdersDAO {
	static Logger log=Logger.getLogger(OrdersDAO.class);
	
	public static List getOrders() throws DBFWException, AdminDAOException, DBConnectionException
	{
		List orders=null;
		ConnectionHolder ch=null;
		Connection con=null;
		try {
			ch=(ConnectionHolder) ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			log.debug("fetching");
			orders=DBHelper.executeSelect(con,SQLMapper.FETCHORDERS,SQLMapper.ORDERSMAPPER);
					
		} catch (DBConnectionException e) {
			throw new DBConnectionException("Unable to connect to db"+e);
		
		}
		finally {

			try {

				if (con != null)
					con.close();

			} catch (SQLException e) {
			}
		}
		
		
		return orders;
		
	}//getorders
	
	//insert
			public static int insertOrders(final Orders o)
			{
				ConnectionHolder ch=null;
				Connection con=null;
				int result=0;
				
				try {
					ch=(ConnectionHolder) ConnectionHolder.getInstance();
					con=ch.getConnection();
					 
					
					
					final ParamMapper INSERTPORDERS= new ParamMapper()
					{
						@Override
						public void mapParams(PreparedStatement preStmt) throws SQLException 
						{
							preStmt.setInt(1, o.getCustomerID());
							preStmt.setString(2, o.getCustomerName());
							preStmt.setString(3, o.getPhoneNo());
							preStmt.setInt(4, o.getQuantity());
							preStmt.setString(5, o.getProductName());
							preStmt.setString(6, o.getReqdate());
							preStmt.setString(7, o.getAddress());
							
						}
					};
					
					
				//result=DBHelper.executeUpdate( con,SQLMapper.INSERTCOUNTRY,INSERTPCOUNTRY);
				result=DBHelper.executeUpdate(con,SQLMapper.INSERTORDERS,INSERTPORDERS);
					
					
				} 
				
				
				catch (DBFWException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (DBConnectionException e)
				
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				return result;
				
				
			}//insert
			
			public static int deleteOrders(int CustomerID)
			{
				ConnectionHolder ch=null;
				Connection con=null;
				int result=0;
				
				try {
					ch=ConnectionHolder.getInstance();
					con=ch.getConnection();
					 
					
				
					final ParamMapper DELETEPORDERS= new ParamMapper()
					{
						@Override
						public void mapParams(PreparedStatement preStmt) throws SQLException 
						{
			
							preStmt.setInt(1, CustomerID);
							//preStmt.setString(2, CustomerName);
							
						}
					};
					
					
				//result=DBHelper.executeUpdate( con,SQLMapper.INSERTCOUNTRY,INSERTPCOUNTRY);
				result=DBHelper.executeUpdate(con,SQLMapper.DELETEORDERS,DELETEPORDERS);
					
					
				} 
				
				
				catch (DBFWException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (DBConnectionException e)
				
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				return result;
			}//delete
			
			
			public static int updateOrders(int CustomerID,String CustomerName,String PhoneNo,int Quantity,String ProductName,String Reqdate,String Address)
			{
				ConnectionHolder ch=null;
				Connection con=null;
				int result=0;
				
				try {
					ch=ConnectionHolder.getInstance();
					con=ch.getConnection();
					 
					
				
					final ParamMapper UPDATEPORDERS= new ParamMapper()
					{
						@Override
						public void mapParams(PreparedStatement preStmt) throws SQLException 
						{
							preStmt.setString(1, CustomerName);
							preStmt.setString(2, PhoneNo);
							preStmt.setInt(3, Quantity);
							preStmt.setString(4, ProductName);
							preStmt.setString(5, Reqdate);
							preStmt.setString(6, Address);
							preStmt.setInt(7, CustomerID);
							//preStmt.setString(2, CustomerName);
							
						}
					};
					
					
				//result=DBHelper.executeUpdate( con,SQLMapper.INSERTCOUNTRY,INSERTPCOUNTRY);
				result=DBHelper.executeUpdate(con,SQLMapper.UPDATEORDERS,UPDATEPORDERS);
					
					
				} 
				
				
				catch (DBFWException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (DBConnectionException e)
				
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				return result;
			}//update
			
			public static List getOrder(final int CustomerID)
			{
				ConnectionHolder ch=null;
				Connection con=null;
				List order=null;
				
				try {
						ch=ConnectionHolder.getInstance();
						con=ch.getConnection();
					final ParamMapper ORDERSPMAPPER=new ParamMapper()
					{

						@Override
						public void mapParams(PreparedStatement preStmt) throws SQLException {
						preStmt.setInt(1,CustomerID);
						//preStmt.setString(2,cname);						
						}
						
					};//ananymous class
					
				order=DBHelper.executeSelect(con,SQLMapper.FETCHCUSTOMERID,SQLMapper.ORDERSMAPPER, ORDERSPMAPPER );		
			
				} catch (DBConnectionException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return order;
				
			}//getorder
			
			
}
