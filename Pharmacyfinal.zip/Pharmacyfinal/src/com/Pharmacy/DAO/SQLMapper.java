package com.Pharmacy.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.Pharmacy.dbfw.ResultMapper;
import com.Pharmacy.Domain.Admin;
import com.Pharmacy.Domain.Customer;
import com.Pharmacy.Domain.Orders;

public class SQLMapper {
	
	public static final String FETCHADMIN= "select * from Admin"; 
	
	public static final String FETCHORDERS= "select * from Orders";
	
	public static final String ADMINLOGIN = "select * from Admin where UserID=? and Password=?";
	
	public static final String CUSTOMERLOGIN = "select * from Customer where UserID=? and Password=?";
	
	public static final String FETCHCUSTOMER= "select * from Customer";
	
	public static final String FETCHADMINID= "select UserID,Password from Admin where UserID=?";
	
	public static final String FETCHCUSTOMERID= "select CustomerID,CustomerName,PhoneNo,Quantity,ProductName,Reqdate,Address from Orders where CustomerID=?";
	
	public static final String FETCHADMINPASSWORD= "select UserID,Password from Admin where Password=?";
	
	public static final String FETCHCUSTOMERPASSWORD= "select UserID,Password from Customer where Password=?";
	
	public static final String INSERTADMIN= "insert into Admin values(?,?,?,?,?,?,?,?)";
	
	public static final String INSERTORDERS= "insert into Orders values(?,?,?,?,?,?,?)";
	
	public static final String INSERTCUSTOMER= "insert into Customer values(?,?,?,?,?,?,?,?)";
	
	public static final String DELETEADMIN="delete from Admin WHERE UserID=?";
	
	public static final String DELETECUSTOMER="delete from Customer WHERE UserID=?";
	
	public static final String DELETEORDERS="delete from Orders WHERE CustomerID=?";
	
	public static final String UPDATEORDERS="update Orders set CustomerName=?,PhoneNo=?,Quantity=?,ProductName=?,Reqdate=?,Address=? WHERE CustomerID=?";
	
	public static final String FETCH_ADMIN = "select name,employeeId,technology,password from user_info where portalid=?";

	public static final ResultMapper ADMINMAPPER = new ResultMapper()
	{
		
		
		@Override
		public Object mapRows(ResultSet rs) throws SQLException
        {
			
		int id=	rs.getInt(1);
		String pass=rs.getString(2);
		String mailid=rs.getString(3);
		int age=rs.getInt(4);
		String cno=rs.getString(5);
		String city=rs.getString(6);
		String state=rs.getString(7);
		String pin=rs.getString(8);
		
		Admin a=new Admin();
			return a;
		}

		};
	//Anonymous class
	
	
	public static final ResultMapper CUSTOMERMAPPER = new ResultMapper()
	{
		
		
		@Override
		public Object mapRows(ResultSet rs) throws SQLException
        {
			
		int id=	rs.getInt(1);
		String pass=rs.getString(2);
		String mailid=rs.getString(3);
		int age=rs.getInt(4);
		String cno=rs.getString(5);
		String city=rs.getString(6);
		String state=rs.getString(7);
		String pin=rs.getString(8);
		
		Customer c=new Customer();
			return c;
		}
	};//Anonymous class
	
	
	public static final ResultMapper ORDERSMAPPER = new ResultMapper()
	{
		
		
		@Override
		public Object mapRows(ResultSet rs) throws SQLException
        {
			
		int id=	rs.getInt(1);
		String name=rs.getString(2);
		String phone=rs.getString(3);
		int quantity=rs.getInt(4);
		String proname=rs.getString(5);
		String date=rs.getString(6);
		String address=rs.getString(7);
		
		
		Orders o=new Orders(id,quantity,name,phone,proname,date,address);;
			return o;
		}
	};//Anonymous class

}
