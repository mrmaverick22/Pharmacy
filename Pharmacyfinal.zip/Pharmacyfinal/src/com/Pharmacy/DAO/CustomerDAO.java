package com.Pharmacy.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

import com.Pharmacy.dbcon.ConnectionHolder;
import com.Pharmacy.dbcon.DBConnectionException;
import com.Pharmacy.dbfw.DBFWException;
import com.Pharmacy.dbfw.DBHelper;
import com.Pharmacy.dbfw.ParamMapper;
import com.Pharmacy.Domain.Admin;
import com.Pharmacy.Domain.Customer;

public class CustomerDAO {
static Logger log=Logger.getLogger(AdminDAO.class);
	
	public static List getCustomer() throws DBFWException, AdminDAOException, DBConnectionException
	{
		List customers=null;
		ConnectionHolder ch=null;
		Connection con=null;
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			log.debug("fetching");
			customers=DBHelper.executeSelect(con,SQLMapper.FETCHCUSTOMER,SQLMapper.CUSTOMERMAPPER);
					
		} catch (DBConnectionException e) {
			throw new DBConnectionException("Unable to connect to db"+e);
		
		}
		finally {

			try {

				if (con != null)
					con.close();

			} catch (SQLException e) {
			}
		}
		
		
		return customers;
		
	}//getcustomer
	
	public static List getCustomer(final int UserID,final String Password )
	{
		ConnectionHolder ch=null;
		Connection con=null;
		List Customer=null;
		
		try {
				ch=ConnectionHolder.getInstance();
				con=ch.getConnection();
			final ParamMapper CUSTOMERPMAPPER=new ParamMapper()
			{

				@Override
				public void mapParams(PreparedStatement preStmt) throws SQLException {
				preStmt.setInt(1,UserID);
				preStmt.setString(2,Password);						
				}
				
			};//ananymous class
			
		Customer=DBHelper.executeSelect(con,SQLMapper.FETCHCUSTOMERID,SQLMapper.CUSTOMERMAPPER, CUSTOMERPMAPPER );		
	
		} catch (DBConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Customer;
		
	}//getCustomer
	
	//insert
		public static int insertCustomer(final Customer c)
		{
			ConnectionHolder ch=null;
			Connection con=null;
			int result=0;
			
			try {
				ch=ConnectionHolder.getInstance();
				con=ch.getConnection();
				 
				
				
				final ParamMapper INSERTPCUSTOMER= new ParamMapper()
				{
					@Override
					public void mapParams(PreparedStatement preStmt) throws SQLException 
					{
						preStmt.setInt(1, c.getUserID());
						preStmt.setString(2, c.getPassword());
						preStmt.setString(3, c.getEmailID());
						preStmt.setInt(4, c.getAge());
						preStmt.setString(5, c.getContact());
						preStmt.setString(6, c.getCity());
						preStmt.setString(7, c.getState());
						preStmt.setString(8, c.getPincode());
						
					}
				};
				
				
			//result=DBHelper.executeUpdate( con,SQLMapper.INSERTCOUNTRY,INSERTPCOUNTRY);
			result=DBHelper.executeUpdate(con,SQLMapper.INSERTCUSTOMER,INSERTPCUSTOMER);
				
				
			} 
			
			
			catch (DBFWException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (DBConnectionException e)
			
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return result;
			
			
		}//insert
		
		public static int customerLogin(int UserID, String Password){
            ConnectionHolder ch=null;
            Connection con=null;
            int result=0;
            try {
                ch=ConnectionHolder.getInstance();
                con=ch.getConnection();
                final ParamMapper CUSTOMERPLOGIN= new ParamMapper()
                {
                    @Override
                    public void mapParams(PreparedStatement preStmt) throws SQLException
                    {
                         preStmt.setInt(1, UserID);
                         preStmt.setString(2, Password);
                       
                    }
                };
            result=DBHelper.executeUpdate(con,SQLMapper.CUSTOMERLOGIN,CUSTOMERPLOGIN);   
            }
           
            catch (DBFWException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (DBConnectionException e){
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return result;
        }//LOGIN

}
