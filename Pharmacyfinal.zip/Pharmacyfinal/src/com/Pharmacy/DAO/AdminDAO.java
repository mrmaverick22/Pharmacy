package com.Pharmacy.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

import com.Pharmacy.DAO.AdminDAO;
import com.Pharmacy.DAO.AdminDAOException;
import com.Pharmacy.DAO.SQLMapper;
import com.Pharmacy.dbcon.ConnectionHolder;
import com.Pharmacy.dbcon.DBConnectionException;
import com.Pharmacy.dbfw.DBFWException;
import com.Pharmacy.dbfw.DBHelper;
import com.Pharmacy.dbfw.ParamMapper;
import com.Pharmacy.Domain.Admin;

public class AdminDAO {
static Logger log=Logger.getLogger(AdminDAO.class);
	
	public static List getAdmins() throws DBFWException, DBConnectionException
	{
		List admins=null;
		ConnectionHolder ch=null;
		Connection con=null;
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			//log.debug("fetching");
			admins=DBHelper.executeSelect(con,SQLMapper.FETCHADMIN,SQLMapper.ADMINMAPPER);
					
		} catch (DBConnectionException e) {
			throw new DBConnectionException("Unable to connect to db"+e);
		
		}
		finally {

			try {

				if (con != null)
					con.close();

			} catch (SQLException e) {
			}
		}
		
		
		return admins;
		
	}//getadmin
	
	public static List getAdmin(final int UserID,final String Password )
	{
		ConnectionHolder ch=null;
		Connection con=null;
		List Admin=null;
		
		try {
				ch=ConnectionHolder.getInstance();
				con=ch.getConnection();
			final ParamMapper ADMINPMAPPER=new ParamMapper()
			{

				@Override
				public void mapParams(PreparedStatement pStmt) throws SQLException {
				pStmt.setInt(1,UserID);
				pStmt.setString(2,Password);
				
				}
				
			};//ananymous class
			
		Admin=DBHelper.executeSelect(con,SQLMapper.FETCHADMINID,SQLMapper.ADMINMAPPER, ADMINPMAPPER );		
	
		} catch (DBConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Admin;
		
	}//getAdmin
	
	//insert
		public static int insertAdmin(final Admin a)
		{
			ConnectionHolder ch=null;
			Connection con=null;
			int result=0;
			
			try {
				ch=ConnectionHolder.getInstance();
				con=ch.getConnection();
				 
				
				
				final ParamMapper INSERTPADMIN= new ParamMapper()
				{
					@Override
					public void mapParams(PreparedStatement preStmt) throws SQLException 
					{
						preStmt.setInt(1, a.getUserID());
						preStmt.setString(2, a.getPassword());
						preStmt.setString(3, a.getEmailID());
						preStmt.setInt(4, a.getAge());
						preStmt.setString(5, a.getContact());
						preStmt.setString(6, a.getCity());
						preStmt.setString(7, a.getState());
						preStmt.setString(8, a.getPincode());
						
					}
				};
				
				
			//result=DBHelper.executeUpdate( con,SQLMapper.INSERTCOUNTRY,INSERTPCOUNTRY);
			result=DBHelper.executeUpdate(con,SQLMapper.INSERTADMIN,INSERTPADMIN);
				
				
			} 
			
			
			catch (DBFWException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (DBConnectionException e)
			
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return result;
			
			
		}//insert
		
		public static int adminLogin(int UserID, String Password){
            ConnectionHolder ch=null;
            Connection con=null;
            int result=0;
            try {
                ch=ConnectionHolder.getInstance();
                con=ch.getConnection();
                final ParamMapper ADMINPLOGIN= new ParamMapper()
                {
                    @Override
                    public void mapParams(PreparedStatement preStmt) throws SQLException
                    {
                         preStmt.setInt(1, UserID);
                         preStmt.setString(2, Password);
                       
                    }
                };
            result=DBHelper.executeUpdate(con,SQLMapper.ADMINLOGIN,ADMINPLOGIN);   
            }
           
            catch (DBFWException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (DBConnectionException e){
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return result;
        }//LOGIN
}
