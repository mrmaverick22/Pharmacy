package com.Pharmacy.DAO;

public class OrdersDAOException extends Exception {
	public OrdersDAOException(String arg0, Throwable arg1) 
	{
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public OrdersDAOException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
