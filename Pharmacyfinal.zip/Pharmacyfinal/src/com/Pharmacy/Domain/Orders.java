package com.Pharmacy.Domain;

public class Orders {
	private int CustomerID,Quantity;
	private String CustomerName,PhoneNo,ProductName,Reqdate,Address;
	
	
	public Orders(int customerID, int quantity, String customerName, String phoneNo, String productName, String reqdate,
			String address) {
		super();
		CustomerID = customerID;
		Quantity = quantity;
		CustomerName = customerName;
		PhoneNo = phoneNo;
		ProductName = productName;
		Reqdate = reqdate;
		Address = address;
	}
	
	public int getCustomerID() {
		return CustomerID;
	}
	public void setCustomerID(int customerID) {
		CustomerID = customerID;
	}
	public int getQuantity() {
		return Quantity;
	}
	public void setQuantity(int quantity) {
		Quantity = quantity;
	}
	public String getCustomerName() {
		return CustomerName;
	}
	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}
	public String getPhoneNo() {
		return PhoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		PhoneNo = phoneNo;
	}
	public String getProductName() {
		return ProductName;
	}
	public void setProductName(String productName) {
		ProductName = productName;
	}
	public String getReqdate() {
		return Reqdate;
	}
	public void setReqdate(String reqdate) {
		Reqdate = reqdate;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	@Override
	public String toString()
	{
		return ("CustomerID-"+CustomerID+", CustomerName-"+CustomerName+", PhoneNo-"+PhoneNo+", Quantity-"+Quantity+", ProductName-"+ProductName+", Reqdate-"+Reqdate+", Address-"+Address).toString();
	}
}
