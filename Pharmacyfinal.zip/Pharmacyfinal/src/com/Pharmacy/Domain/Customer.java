package com.Pharmacy.Domain;

public class Customer {
	private int UserID,Age;
	private String Password,EmailID,Contact,City,State,Pincode;
	
	public int getUserID() {
		return UserID;
	}
	public void setUserID(int userID) {
		UserID = userID;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {
		Age = age;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getEmailID() {
		return EmailID;
	}
	public void setEmailID(String emailID) {
		EmailID = emailID;
	}
	public String getContact() {
		return Contact;
	}
	public void setContact(String contact) {
		Contact = contact;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public String getPincode() {
		return Pincode;
	}
	public void setPincode(String pincode) {
		Pincode = pincode;
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Customer [UserID=");
		builder.append(UserID);
		builder.append(", Password=");
		builder.append(Password);
		builder.append(", EmailID=");
		builder.append(EmailID);
		builder.append(", Contact=");
		builder.append(Contact);
		builder.append(", City=");
		builder.append(City);
		builder.append(", State=");
		builder.append(State);
		builder.append(", Pincode=");
		builder.append(Pincode);
		builder.append("]");
		return builder.toString();
	}

}
