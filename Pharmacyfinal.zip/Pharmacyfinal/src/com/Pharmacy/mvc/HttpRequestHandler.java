package com.Pharmacy.mvc;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Pharmacy.DAO.AdminDAOException;
import com.Pharmacy.DAO.DAOAppException;
import com.Pharmacy.dbcon.DBConnectionException;
import com.Pharmacy.dbfw.DBFWException;

public interface HttpRequestHandler {
	public void handle(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, DBFWException, AdminDAOException, DBConnectionException,DAOAppException;

	


}
