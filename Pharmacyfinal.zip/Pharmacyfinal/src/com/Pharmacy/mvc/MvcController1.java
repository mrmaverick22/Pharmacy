package com.Pharmacy.mvc;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.Pharmacy.DAO.AdminDAOException;
import com.Pharmacy.DAO.DAOAppException;
import com.Pharmacy.dbcon.DBConnectionException;
import com.Pharmacy.dbfw.DBFWException;
import com.Pharmacy.mvc.HttpRequestHandler;
import com.Pharmacy.mvc.MvcController1;
import com.Pharmacy.mvc.MvcException;
import com.Pharmacy.mvc.MvcUtil;


public class MvcController1 extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet 
{
		public static final Logger log = Logger.getLogger(MvcController1.class);
		private Map handlers;

		static final long serialVersionUID = 1L;

		public void init(final ServletConfig config) throws ServletException {
			super.init(config);
			final String mvcProps = getServletContext().getRealPath("/WEB-INF/mvc.properties");
			try 
			{
				this.handlers = MvcUtil.buildHandlers(mvcProps);
				log.info(handlers);
			} catch (MvcException e) {
				throw new ServletException("Unable to configure controller servlet", e);
}
}

		protected void doGet(final HttpServletRequest request,final HttpServletResponse response) throws ServletException, IOException {
			String url = request.getServletPath();
			File f = new File(url);
			String file = f.getName();
			String key = file.substring(0, file.lastIndexOf('.'));
			log.info(key);
			HttpRequestHandler handler = (HttpRequestHandler) handlers.get(key);
			if (handler != null) {
				try {
					handler.handle(request, response);
				} catch (DBFWException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (AdminDAOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (DBConnectionException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (DAOAppException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				throw new ServletException("No matching handler");
}
}

		protected void doPost(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			doGet(request, response);

}
}
